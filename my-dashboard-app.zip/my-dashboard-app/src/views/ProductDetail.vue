<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import { Product } from "../types";
import { fetchHelper } from "../utils/fetchHelper";

import Sidebar from "../components/Sidebar.vue";
import Header from "../components/Header.vue";
import ProductDetailCard from "../components/ProductDetailCard.vue";

const route = useRoute();

const product = ref<Product | null>(null);
const id = ref(route.params.id);

onMounted(async () => {
 try {
  const data = await fetchHelper<Product>(`https://dummyjson.com/products/${id.value}`);
  product.value = data;
 } catch (err) {
  console.error("Failed to fetch product details:", err);
 }
});
</script>

<template>
 <Sidebar />

 <div>
  <main class="py-4 lg:pl-72">
   <div class="px-4 sm:px-6 lg:px-8">
    <div class="hidden lg:block">
     <Header />
    </div>

    <div class="py-4 px-4 sm:px-6 lg:px-8">
     <div class="lg:flex lg:items-center lg:justify-between pb-5">
      <h2 class="text-2xl font-bold leading-7 sm:truncate sm:text-3xl sm:tracking-tight">
       Product Details
      </h2>
     </div>

     <ProductDetailCard :product="product" />
    </div>
   </div>
  </main>
 </div>
</template>
