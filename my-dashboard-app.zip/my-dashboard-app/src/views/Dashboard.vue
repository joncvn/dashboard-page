<script setup lang="ts">
import { ref, onMounted } from "vue";
import { Product, ProductsApiResponse } from "../types";
import { fetchHelper } from "../utils/fetchHelper";

import Sidebar from "../components/Sidebar.vue";
import Header from "../components/Header.vue";
import ProductsTable from "../components/ProductsTable.vue";

const products = ref<Product[]>([]);

onMounted(async () => {
 try {
  const data = await fetchHelper<ProductsApiResponse>("https://dummyjson.com/products");
  products.value = [...data.products];
 } catch (err) {
  console.error("Failed to fetch products:", err);
 }
});
</script>

<template>
 <Sidebar />

 <div>
  <main class="py-4 lg:pl-72">
   <div class="px-4 sm:px-6 lg:px-8">
    <div class="hidden lg:block">
     <Header />
    </div>

    <div class="py-4 px-4 sm:px-6 lg:px-8">
     <div class="lg:flex lg:items-center lg:justify-between">
      <h2 class="text-2xl font-bold leading-7 sm:truncate sm:text-3xl sm:tracking-tight">
       Products Information
      </h2>
     </div>

     <ProductsTable :products="products" />
    </div>
   </div>
  </main>
 </div>
</template>
