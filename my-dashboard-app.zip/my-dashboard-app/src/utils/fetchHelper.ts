async function fetchHelper<T>(url: string): Promise<T> {
 try {
  const response = await fetch(url);

  if (!response.ok) {
   throw new Error(response.statusText);
  }

  const data: T = await response.json();
  return data;
 } catch (error) {
  throw error;
 }
}

export { fetchHelper };
