import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { fetchHelper } from "../fetchHelper";
import { ProductsApiResponse } from "../../types"; // Import the types

// Fetch mock
beforeEach(() => {
 vi.restoreAllMocks();
});

// Clean mock
afterEach(() => {
 vi.restoreAllMocks();
});

describe("fetchHelper", () => {
 it("should fetch and return data when response is ok", async () => {
  // Arrange
  const mockData: ProductsApiResponse = {
   products: [
    {
     id: 1,
     title: "iPhone 9",
     description: "An apple mobile which is nothing like apple",
     price: 549,
     discountPercentage: 12.96,
     rating: 4.69,
     stock: 94,
     brand: "Apple",
     category: "smartphones",
     thumbnail: "thumbnail.jpg",
     images: ["image1.jpg", "image2.jpg"],
    },
   ],
   total: 100,
   skip: 0,
   limit: 30,
  };
  vi.stubGlobal(
   "fetch",
   vi.fn(() =>
    Promise.resolve({
     ok: true,
     json: () => Promise.resolve(mockData),
    })
   )
  );

  const url = "https://dummyjson.com/products";

  // Act
  const data = await fetchHelper<ProductsApiResponse>(url);

  // Assert
  expect(fetch).toHaveBeenCalledWith(url);
  expect(data).toEqual(mockData);
 });

 it("should throw an error when response is not ok", async () => {
  // Arrange
  const mockError = "Not Found";
  vi.stubGlobal(
   "fetch",
   vi.fn(() =>
    Promise.resolve({
     ok: false,
     statusText: mockError,
    })
   )
  );

  const url = "https://dummyjson.com/products";

  // Act & Assert
  await expect(fetchHelper(url)).rejects.toThrow(new Error(mockError));
  expect(fetch).toHaveBeenCalledWith(url);
 });
});
