<script setup lang="ts">
import { BellIcon } from "@heroicons/vue/24/outline";
</script>

<template>
 <span class="relative inline-block bg-white p-2 rounded-md text-gray-400">
  <span class="absolute -inset-1.5" />
  <BellIcon class="h-6 w-6" aria-hidden="true" />
  <span
   class="absolute right-0 top-0 block h-2 w-2 -translate-y-1/2 translate-x-1/2 transform rounded-full bg-amber-500 ring-2 ring-amber-100"
  />
 </span>
</template>
