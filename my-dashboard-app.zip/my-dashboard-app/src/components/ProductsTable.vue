<script setup lang="ts">
import { ref, computed } from "vue";
import { Product } from "../types";

import { ChevronDownIcon } from "@heroicons/vue/20/solid";

const props = defineProps<{ products: Product[] }>();

const searchTitle = ref("");
const searchBrand = ref("");
const sortBy = ref("");
const sortOrder = ref("ascending");
const selectedProducts = ref<number[]>([]);

const handleBulkSelect = (event: Event) => {
 const target = event.target as HTMLInputElement;
 if (target) {
  selectedProducts.value = target.checked ? props.products.map((p) => p.id) : [];
 }
};

const indeterminate = computed(
 () => selectedProducts.value.length > 0 && selectedProducts.value.length < props.products.length
);

const filteredProducts = computed(() => filterProducts());

const updateProducts = () => {
 filteredProducts.value;
};

const filterProducts = () => {
 let filtered = props.products;

 if (searchTitle.value) {
  filtered = filtered.filter((product) =>
   product.title.toLowerCase().includes(searchTitle.value.toLowerCase())
  );
 }

 if (searchBrand.value) {
  filtered = filtered.filter((product) =>
   product.brand.toLowerCase().includes(searchBrand.value.toLowerCase())
  );
 }

 return filtered;
};

const sortProducts = (field: string) => {
 if (sortBy.value === field) {
  sortOrder.value = sortOrder.value === "ascending" ? "descending" : "ascending";
 } else {
  sortBy.value = field;
  sortOrder.value = "ascending";
 }
};

const productArrayData = computed(() => {
 let sorted = filterProducts();

 if (sortBy.value) {
  sorted = sorted.slice().sort((a, b) => {
   const aValue = a[sortBy.value];
   const bValue = b[sortBy.value];

   if (typeof aValue === "string" && typeof bValue === "string") {
    return sortOrder.value === "ascending"
     ? aValue.localeCompare(bValue)
     : bValue.localeCompare(aValue);
   }

   return 0;
  });
 }

 return sorted;
});
</script>

<template>
 <div class="mt-8 flow-root">
  <div class="flex space-x-6 pb-5">
   <div class="maw-w-xl">
    <label for="search-title" class="block text-sm font-medium leading-6 text-gray-900">
     Title
    </label>
    <div class="mt-2">
     <input
      v-model="searchTitle"
      type="text"
      name="search-title"
      id="search-title"
      class="block w-full rounded-md border-0 py-2 pl-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-blue-600 sm:text-sm sm:leading-6"
      placeholder="Enter title"
      @input="updateProducts"
     />
    </div>
   </div>

   <div>
    <label for="email" class="block text-sm font-medium leading-6 text-gray-900">Brand</label>
    <div class="mt-2">
     <input
      v-model="searchBrand"
      type="email"
      name="email"
      id="email"
      class="block w-full rounded-md border-0 py-2 pl-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-blue-600 sm:text-sm sm:leading-6"
      placeholder="Enter brand"
      @input="updateProducts"
     />
    </div>
   </div>
  </div>

  <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
   <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
    <div class="relative">
     <div
      v-if="selectedProducts.length > 0"
      class="absolute left-14 top-0 flex h-12 items-center space-x-3 bg-white sm:left-12"
     >
      <button
       type="button"
       class="inline-flex items-center rounded bg-white px-2 py-1 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-white"
      >
       Bulk edit
      </button>
      <button
       type="button"
       class="inline-flex items-center rounded bg-white px-2 py-1 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-white"
      >
       Delete all
      </button>
     </div>
     <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
      <table class="min-w-full table-fixed divide-y divide-gray-300">
       <thead class="bg-white">
        <tr>
         <th scope="col" class="relative px-7 sm:w-12 sm:px-6">
          <input
           type="checkbox"
           class="absolute left-4 top-1/2 -mt-2 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-600"
           :checked="indeterminate || selectedProducts.length === products.length"
           :indeterminate="indeterminate"
           @change="handleBulkSelect($event)"
          />
         </th>
         <th
          scope="col"
          class="min-w-[12rem] py-3.5 pr-3 text-left text-sm font-semibold text-gray-900"
         >
          <span class="group inline-flex">
           Title
           <span
            @click="sortProducts('title')"
            class="hover:cursor-pointer ml-2 flex-none rounded bg-gray-100 text-gray-900 group-hover:bg-gray-200"
           >
            <ChevronDownIcon
             :class="['h-5 w-5', { 'rotate-180': sortBy === 'title' && sortOrder === 'ascending' }]"
             aria-hidden="true"
            />
           </span>
          </span>
         </th>
         <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
          Category
         </th>
         <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
          <a href="#" class="group inline-flex">
           Brand
           <span
            @click="sortProducts('brand')"
            class="ml-2 flex-none rounded bg-gray-100 text-gray-900 group-hover:bg-gray-200"
           >
            <ChevronDownIcon
             :class="['h-5 w-5', { 'rotate-180': sortBy === 'brand' && sortOrder === 'ascending' }]"
             aria-hidden="true"
            />
           </span>
          </a>
         </th>
         <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
          Price
         </th>
         <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
          Stock
         </th>
         <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
          Rating
         </th>
        </tr>
       </thead>

       <tbody class="divide-y divide-gray-200 bg-white">
        <tr
         v-for="person in productArrayData"
         :key="person.id"
         :class="[selectedProducts.includes(person.id) && 'bg-gray-50']"
        >
         <td class="relative px-7 sm:w-12 sm:px-6">
          <div
           v-if="selectedProducts.includes(person.id)"
           class="absolute inset-y-0 left-0 w-0.5 bg-blue-600"
          ></div>
          <input
           type="checkbox"
           class="absolute left-4 top-1/2 -mt-2 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-600"
           :value="person.id"
           v-model="selectedProducts"
          />
         </td>
         <td
          :class="[
           'whitespace-nowrap py-4 pr-3 text-sm font-semibold',
           selectedProducts.includes(person.id) ? 'text-blue-600' : 'text-blue-500',
          ]"
         >
          <router-link
           :to="{ name: 'ProductDetail', params: { id: person.id } }"
           class="hover:underline"
          >
           {{ person.title }}
          </router-link>
         </td>
         <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
          {{ person.category }}
         </td>
         <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
          {{ person.brand }}
         </td>
         <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">${{ person.price }}</td>
         <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
          {{ person.stock }}
         </td>
         <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{{ person.rating }}/5</td>
        </tr>
       </tbody>
      </table>
     </div>
    </div>
   </div>
  </div>
 </div>
</template>
