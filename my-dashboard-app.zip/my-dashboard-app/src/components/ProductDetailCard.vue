<script setup lang="ts">
import { Product } from "../types";

defineProps<{ product: Product | null }>();
</script>

<template>
 <div class="overflow-hidden bg-white shadow sm:rounded-lg">
  <div class="border-t border-gray-100">
   <dl class="divide-y divide-gray-100">
    <div class="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
     <dt class="text-sm font-semibold text-gray-900">Full name</dt>
     <dd class="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
      {{ product?.title }}
     </dd>
    </div>
    <div class="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
     <dt class="text-sm font-semibold text-gray-900">Price</dt>
     <dd class="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
      $ {{ product?.price }}
      <span class="font-semibold text-xs">({{ product?.discountPercentage }}% off)</span>
     </dd>
    </div>
    <div class="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
     <dt class="text-sm font-semibold text-gray-900">Number of product available</dt>
     <dd class="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
      {{ product?.stock }}
     </dd>
    </div>
    <div class="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
     <dt class="text-sm font-semibold text-gray-900">Description</dt>
     <dd class="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
      {{ product?.description }}
     </dd>
    </div>
    <div class="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
     <dt class="text-sm font-semibold text-gray-900">Rating</dt>
     <dd class="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
      {{ product?.rating }}/5
     </dd>
    </div>
    <div class="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
     <dd class="mt-2 text-sm text-gray-900 sm:col-span-3 sm:mt-0">
      <ul
       role="list"
       class="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 sm:gap-x-6 lg:grid-cols-4 xl:gap-x-8"
      >
       <li v-for="(image, idx) in product?.images" :key="idx" class="relative">
        <div class="group aspect-h-7 aspect-w-10 block w-full overflow-hidden rounded-lg">
         <img :src="image" alt="" class="pointer-events-none object-cover" />
        </div>
       </li>
      </ul>
     </dd>
    </div>
   </dl>
  </div>
 </div>
</template>
