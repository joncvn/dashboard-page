<script setup lang="ts">
import NotificationsButton from "./NotificationsButton.vue";
import MainSearch from "./MainSearch.vue";
import ProfileMenuIcon from "./ProfileMenuIcon.vue";

import { Disclosure, DisclosureButton } from "@headlessui/vue";
import { Bars3Icon, XMarkIcon } from "@heroicons/vue/24/outline";
</script>

<template>
 <Disclosure as="nav" v-slot="{ open }">
  <div class="mx-auto">
   <div class="flex h-16 justify-between">
    <div class="flex flex-1 items-center justify-center px-2 lg:ml-6 lg:justify-start">
     <div class="w-full max-w-lg lg:max-w-xl">
      <MainSearch />
     </div>
    </div>
    <div class="flex items-center lg:hidden">
     <DisclosureButton
      class="relative inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
     >
      <span class="absolute -inset-0.5" />
      <span class="sr-only">Open main menu</span>
      <Bars3Icon v-if="!open" class="block h-6 w-6" aria-hidden="true" />
      <XMarkIcon v-else class="block h-6 w-6" aria-hidden="true" />
     </DisclosureButton>
    </div>
    <div class="hidden lg:ml-4 lg:flex lg:items-center">
     <NotificationsButton />
     <ProfileMenuIcon />
    </div>
   </div>
  </div>
 </Disclosure>
</template>
